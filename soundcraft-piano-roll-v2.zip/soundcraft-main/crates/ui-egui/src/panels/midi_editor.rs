//! The MIDI Editor: a piano roll with scale highlighting, ghost notes, wide X/Y zoom bars,
//! live note audition, and a velocity lane, docked under the Edit window.

use crate::SoundApp;
use crate::theme::{Tokens, bold, regular};
use egui::{Align2, Color32, Rect, Sense, Stroke, StrokeKind, Ui, pos2, vec2};
use serde_json::json;
use soundcraft_model::{ClipContent, ClipId, Tool};
use soundcraft_time::TICKS_PER_QUARTER;

const KEY_W: f32 = 54.0;
const ROW_H: f32 = 10.0;
const VEL_H: f32 = 60.0;
const ZOOM_BAR_H: f32 = 16.0;

const ZOOM_X_MIN: f32 = 0.05;
const ZOOM_X_MAX: f32 = 64.0;
const ZOOM_Y_MIN: f32 = 0.35;
const ZOOM_Y_MAX: f32 = 6.0;

const ROOT_NAMES: [&str; 12] = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScaleKind {
    Chromatic,
    Major,
    NaturalMinor,
    HarmonicMinor,
    MelodicMinor,
    Dorian,
    Mixolydian,
    MajorPentatonic,
    MinorPentatonic,
    Blues,
}

impl ScaleKind {
    const ALL: [ScaleKind; 10] = [
        ScaleKind::Chromatic,
        ScaleKind::Major,
        ScaleKind::NaturalMinor,
        ScaleKind::HarmonicMinor,
        ScaleKind::MelodicMinor,
        ScaleKind::Dorian,
        ScaleKind::Mixolydian,
        ScaleKind::MajorPentatonic,
        ScaleKind::MinorPentatonic,
        ScaleKind::Blues,
    ];

    fn label(self) -> &'static str {
        match self {
            ScaleKind::Chromatic => "Chromatic (Off)",
            ScaleKind::Major => "Major (Ionian)",
            ScaleKind::NaturalMinor => "Natural Minor (Aeolian)",
            ScaleKind::HarmonicMinor => "Harmonic Minor",
            ScaleKind::MelodicMinor => "Melodic Minor",
            ScaleKind::Dorian => "Dorian",
            ScaleKind::Mixolydian => "Mixolydian",
            ScaleKind::MajorPentatonic => "Major Pentatonic",
            ScaleKind::MinorPentatonic => "Minor Pentatonic",
            ScaleKind::Blues => "Blues",
        }
    }

    fn contains(self, semitone_from_root: u8) -> bool {
        let s = semitone_from_root % 12;
        match self {
            ScaleKind::Chromatic => true,
            ScaleKind::Major => matches!(s, 0 | 2 | 4 | 5 | 7 | 9 | 11),
            ScaleKind::NaturalMinor => matches!(s, 0 | 2 | 3 | 5 | 7 | 8 | 10),
            ScaleKind::HarmonicMinor => matches!(s, 0 | 2 | 3 | 5 | 7 | 8 | 11),
            ScaleKind::MelodicMinor => matches!(s, 0 | 2 | 3 | 5 | 7 | 9 | 11),
            ScaleKind::Dorian => matches!(s, 0 | 2 | 3 | 5 | 7 | 9 | 10),
            ScaleKind::Mixolydian => matches!(s, 0 | 2 | 4 | 5 | 7 | 9 | 10),
            ScaleKind::MajorPentatonic => matches!(s, 0 | 2 | 4 | 7 | 9),
            ScaleKind::MinorPentatonic => matches!(s, 0 | 3 | 5 | 7 | 10),
            ScaleKind::Blues => matches!(s, 0 | 3 | 5 | 6 | 7 | 10),
        }
    }
}

#[derive(Debug, Clone)]
pub struct MidiEditorState {
    pub selected: Vec<usize>,
    pub drag: Option<NoteDrag>,
    pub scroll: f32,
    /// Horizontal scroll measured in MIDI ticks from the clip start.
    pub scroll_x_ticks: f32,
    /// Independent horizontal and vertical zoom factors.
    pub zoom_x: f32,
    pub zoom_y: f32,
    pub clip: Option<ClipId>,
    /// Rubber-band selection start (screen position).
    pub band: Option<egui::Pos2>,
    /// Scale highlight settings.
    pub root_key: u8,
    pub scale: ScaleKind,
    /// Show ghost notes from other MIDI tracks/clips in the playlist.
    pub show_ghosts: bool,
    /// Currently auditioned pitch (from clicking piano keys or adding notes) and frames left.
    pub audition_pitch: Option<u8>,
    pub audition_frames: u8,
}

impl Default for MidiEditorState {
    fn default() -> Self {
        Self {
            selected: Vec::new(),
            drag: None,
            scroll: 0.0,
            scroll_x_ticks: 0.0,
            zoom_x: 1.0,
            zoom_y: 1.0,
            clip: None,
            band: None,
            root_key: 0, // C
            scale: ScaleKind::NaturalMinor,
            show_ghosts: true,
            audition_pitch: None,
            audition_frames: 0,
        }
    }
}

impl MidiEditorState {
    fn switch_clip(&mut self, id: ClipId) {
        if self.clip != Some(id) {
            self.selected.clear();
            self.drag = None;
            self.band = None;
            self.scroll_x_ticks = 0.0;
        }
        self.clip = Some(id);
    }
}

#[derive(Debug, Clone)]
pub struct NoteDrag {
    pub index: usize,
    pub resize: bool,
    pub start: egui::Pos2,
    pub dx_ticks: i64,
    pub dy_semi: i64,
}

pub fn target_clip(app: &SoundApp) -> Option<ClipId> {
    let s = app.engine.session();
    for id in &s.edit.selected_clips {
        if let Some((_, c)) = s.find_clip(*id)
            && matches!(c.content, ClipContent::Midi { .. })
        {
            return Some(*id);
        }
    }
    let at = s.edit.selection.start;
    s.tracks
        .iter()
        .filter(|t| s.edit.selected_tracks.contains(&t.id) && t.kind.is_midi())
        .flat_map(|t| t.clips().iter())
        .find(|c| c.range().contains(at) || c.range().overlaps(&s.edit.selection))
        .or_else(|| {
            s.tracks
                .iter()
                .filter(|t| s.edit.selected_tracks.contains(&t.id) && t.kind.is_midi())
                .flat_map(|t| t.clips().iter())
                .next()
        })
        .map(|c| c.id)
}

fn is_black(p: i32) -> bool {
    matches!(p.rem_euclid(12), 1 | 3 | 6 | 8 | 10)
}

#[derive(Clone, Copy)]
struct Roll<'a> {
    sequence: &'a soundcraft_midi::Sequence,
    roll: Rect,
    keys: Rect,
    vel: Rect,
    px_per_tick: f32,
    len_ticks: i64,
    scroll: f32,
    scroll_x_ticks: f32,
    row_h: f32,
    grid_ticks: i64,
    rows: i32,
}

impl Roll<'_> {
    fn x_of(&self, tick: i64) -> f32 {
        self.roll.min.x + (tick as f32 - self.scroll_x_ticks) * self.px_per_tick
    }

    fn y_of(&self, pitch: i32) -> f32 {
        self.roll.min.y + (127 - pitch) as f32 * self.row_h - self.scroll
    }

    fn pitch_at(&self, y: f32) -> i32 {
        127 - ((y - self.roll.min.y + self.scroll) / self.row_h).floor() as i32
    }

    fn hit(&self, pos: egui::Pos2) -> Option<(usize, bool)> {
        if !self.roll.contains(pos) {
            return None;
        }
        self.sequence.notes.iter().enumerate().rev().find_map(|(i, n)| {
            let r = Rect::from_min_max(
                pos2(self.x_of(n.start), self.y_of(i32::from(n.pitch))),
                pos2(
                    self.x_of(n.start + n.length).max(self.x_of(n.start) + 4.0),
                    self.y_of(i32::from(n.pitch)) + self.row_h,
                ),
            );
            r.contains(pos).then_some((i, pos.x > r.max.x - 5.0))
        })
    }

    fn snap(&self, tk: f32) -> i64 {
        ((tk / self.grid_ticks as f32).round() as i64) * self.grid_ticks
    }
}

fn trigger_audition(app: &mut SoundApp, pitch: u8, frames: u8) {
    if let Some(prev) = app.midi.audition_pitch.take() {
        app.audition_midi_note(prev, 0);
    }
    app.audition_midi_note(pitch, 105);
    app.midi.audition_pitch = Some(pitch);
    app.midi.audition_frames = frames;
}

pub fn show(app: &mut SoundApp, ui: &mut Ui) {
    if app.midi.audition_frames > 0 {
        app.midi.audition_frames -= 1;
        if app.midi.audition_frames == 0
            && let Some(p) = app.midi.audition_pitch.take()
        {
            app.audition_midi_note(p, 0);
        } else {
            ui.ctx().request_repaint();
        }
    }

    ui.take_available_space();
    let t = Tokens::current();
    let full = ui.max_rect();
    ui.painter().rect_filled(full, 0.0, t.panel_bg);

    let header = Rect::from_min_size(full.min, vec2(full.width(), 24.0));
    ui.painter().rect_filled(header, 0.0, t.panel_bg2);
    ui.painter().text(
        pos2(header.min.x + 8.0, header.center().y),
        Align2::LEFT_CENTER,
        crate::localization::text("MIDI EDITOR"),
        bold(11.5),
        t.header_text,
    );

    let Some(cid) = target_clip(app) else {
        empty_state(app, ui, full, header);
        return;
    };
    let Some((track, clip)) = app.engine.session().find_clip(cid).map(|(t, c)| (t, c.clone())) else {
        return;
    };
    let ClipContent::Midi { sequence } = &clip.content else {
        return;
    };
    let track_color = app.engine.session().track(track).map_or([120, 120, 200], |t| t.color);

    let grid_ticks = grid_ticks_of(app);
    midi_toolbar(app, ui, header, cid, grid_ticks);

    // Dedicated Zoom Control Strip (adjustable X and Y zoom bars) right below the header.
    let zoom_strip = Rect::from_min_size(pos2(full.min.x, header.max.y), vec2(full.width(), ZOOM_BAR_H));
    ui.painter().rect_filled(zoom_strip, 0.0, Color32::from_rgb(24, 24, 27));
    draw_zoom_bars(app, ui, zoom_strip);

    let s = app.engine.session_arc();
    let sr = s.sample_rate;
    let base_tick = s.tempo.samples_to_ticks(clip.start, sr);
    let len_ticks = (s.tempo.samples_to_ticks(clip.end(), sr) - base_tick).max(1);

    // Strictly separate `keys` (left) and `roll` (right) so zoomed notes never overlap the keyboard.
    let roll = Rect::from_min_max(
        pos2(full.min.x + KEY_W, zoom_strip.max.y + 1.0),
        pos2(full.max.x - 4.0, full.max.y - VEL_H - 4.0),
    );
    let keys = Rect::from_min_max(pos2(full.min.x, roll.min.y), pos2(full.min.x + KEY_W - 1.0, roll.max.y));
    let vel = Rect::from_min_max(pos2(roll.min.x, roll.max.y + 4.0), pos2(roll.max.x, full.max.y - 2.0));

    if app.midi.clip != Some(cid) {
        let hi = sequence.notes.iter().map(|n| i32::from(n.pitch)).max().unwrap_or(72);
        let lo = sequence.notes.iter().map(|n| i32::from(n.pitch)).min().unwrap_or(48);
        let initial_row_h = ROW_H;
        let rows = (roll.height() / initial_row_h).floor() as i32;
        app.midi.scroll = (127 - (hi + lo) / 2 - rows / 2) as f32 * initial_row_h;
        app.midi.switch_clip(cid);
    }

    app.midi.zoom_x = app.midi.zoom_x.clamp(ZOOM_X_MIN, ZOOM_X_MAX);
    app.midi.zoom_y = app.midi.zoom_y.clamp(ZOOM_Y_MIN, ZOOM_Y_MAX);
    let row_h = ROW_H * app.midi.zoom_y;
    let px_per_tick = roll.width() / len_ticks as f32 * app.midi.zoom_x;

    // Pointer-anchored X and Y zoom + smooth scrolling inside the roll area.
    let pointer = ui.ctx().pointer_latest_pos().filter(|p| roll.contains(*p));
    if let Some(pointer) = pointer {
        let (delta, modifiers) = ui.input(|i| (i.smooth_scroll_delta, i.modifiers));
        if delta.y != 0.0 {
            if modifiers.alt {
                let old_pitch = 127.0 - ((pointer.y - roll.min.y + app.midi.scroll) / row_h);
                let factor = (1.0 + delta.y * 0.012).clamp(0.4, 2.5);
                app.midi.zoom_y = (app.midi.zoom_y * factor).clamp(ZOOM_Y_MIN, ZOOM_Y_MAX);
                let new_row_h = ROW_H * app.midi.zoom_y;
                app.midi.scroll = (127.0 - old_pitch) * new_row_h - (pointer.y - roll.min.y);
            } else if modifiers.ctrl || modifiers.command {
                let old_px = px_per_tick.max(0.0001);
                let anchor_tick = app.midi.scroll_x_ticks + (pointer.x - roll.min.x) / old_px;
                let factor = (1.0 + delta.y * 0.015).clamp(0.4, 2.5);
                app.midi.zoom_x = (app.midi.zoom_x * factor).clamp(ZOOM_X_MIN, ZOOM_X_MAX);
                let new_px = roll.width() / len_ticks as f32 * app.midi.zoom_x;
                app.midi.scroll_x_ticks = anchor_tick - (pointer.x - roll.min.x) / new_px.max(0.0001);
            } else {
                app.midi.scroll -= delta.y;
            }
        }
        if delta.x != 0.0 {
            app.midi.scroll_x_ticks -= delta.x / px_per_tick.max(0.0001);
        }
    }

    let visible_ticks = roll.width() / px_per_tick.max(0.0001);
    app.midi.scroll_x_ticks = app.midi.scroll_x_ticks.clamp(0.0, (len_ticks as f32 - visible_ticks).max(0.0));
    app.midi.scroll = app.midi.scroll.clamp(0.0, (128.0 * row_h - roll.height()).max(0.0));

    let g = Roll {
        sequence,
        roll,
        keys,
        vel,
        px_per_tick,
        len_ticks,
        scroll: app.midi.scroll,
        scroll_x_ticks: app.midi.scroll_x_ticks,
        row_h,
        grid_ticks,
        rows: (roll.height() / row_h).ceil() as i32,
    };

    // 1. Paint roll background + scale highlights clipped strictly to `roll`.
    let roll_painter = ui.painter().with_clip_rect(roll);
    draw_roll_background(&roll_painter, &g, app.midi.root_key, app.midi.scale);

    // 2. Paint ghost notes from other MIDI clips in the playlist (if enabled).
    if app.midi.show_ghosts {
        draw_ghost_notes(&roll_painter, &g, &s, cid, base_tick, sr);
    }

    // 3. Paint active clip notes clipped strictly to `roll`.
    let base = Color32::from_rgb(track_color[0], track_color[1], track_color[2]);
    draw_notes(app, &roll_painter, &g, base);

    // 4. Playhead clipped strictly to `roll`.
    let playhead_tick = s.tempo.samples_to_ticks(app.position(), sr) - base_tick;
    if (0..=len_ticks).contains(&playhead_tick) {
        let x = g.x_of(playhead_tick);
        if x >= roll.min.x && x <= roll.max.x {
            roll_painter.line_segment(
                [pos2(x, roll.min.y), pos2(x, roll.max.y)],
                Stroke::new(1.5, if app.engine.transport.recording { t.playhead } else { t.playback }),
            );
        }
    }

    // 5. Paint and handle clicks on the piano keyboard clipped strictly to `keys`.
    let key_painter = ui.painter().with_clip_rect(keys);
    draw_and_interact_keys(app, ui, &key_painter, &g);

    // Divider line separating keys and grid.
    ui.painter().line_segment(
        [pos2(keys.max.x, roll.min.y), pos2(keys.max.x, roll.max.y)],
        Stroke::new(1.0, Color32::from_rgb(70, 70, 76)),
    );

    note_pointer(app, ui, &g, cid, s.edit.tool == Tool::Pencil);
    note_keys(app, ui, &g, cid);
    velocity_lane(app, ui, &g, cid, base, full.min.x + 6.0);
}

fn draw_zoom_bars(app: &mut SoundApp, ui: &mut Ui, strip: Rect) {
    let mut child = ui.new_child(
        egui::UiBuilder::new()
            .max_rect(strip.shrink2(vec2(8.0, 1.0)))
            .layout(egui::Layout::left_to_right(egui::Align::Center)),
    );
    child.spacing_mut().item_spacing.x = 8.0;
    child.label(egui::RichText::new("Zoom X:").font(regular(10.5)));
    child.add(
        egui::Slider::new(&mut app.midi.zoom_x, ZOOM_X_MIN..=ZOOM_X_MAX)
            .logarithmic(true)
            .show_value(true)
            .custom_formatter(|v, _| format!("{v:.2}x")),
    );
    if child.small_button("1x X").clicked() {
        app.midi.zoom_x = 1.0;
        app.midi.scroll_x_ticks = 0.0;
    }

    child.separator();
    child.label(egui::RichText::new("Zoom Y:").font(regular(10.5)));
    child.add(
        egui::Slider::new(&mut app.midi.zoom_y, ZOOM_Y_MIN..=ZOOM_Y_MAX)
            .show_value(true)
            .custom_formatter(|v, _| format!("{v:.2}x")),
    );
    if child.small_button("1x Y").clicked() {
        app.midi.zoom_y = 1.0;
    }
}

fn empty_state(app: &mut SoundApp, ui: &mut Ui, full: Rect, header: Rect) {
    let t = Tokens::current();
    let track = {
        let s = app.engine.session();
        s.tracks
            .iter()
            .find(|t| t.kind.is_midi() && s.edit.selected_tracks.contains(&t.id))
            .map(|t| (t.id, t.name.clone()))
    };
    let msg = match &track {
        Some((_, name)) => crate::localized_format!("Click to add a MIDI clip to {name} at the insertion point.", name = name),
        None => crate::localization::text("Select a MIDI clip (or a MIDI track) to edit its notes.").into(),
    };
    ui.painter().text(full.center(), Align2::CENTER_CENTER, msg, regular(13.0), t.text_dim);
    let body = Rect::from_min_max(pos2(full.min.x, header.max.y), full.max);
    if let Some((id, _)) = track
        && ui.interact(body, ui.scope_id().with("new_clip"), Sense::click()).clicked()
    {
        let sel = app.engine.session().edit.selection;
        if let Ok(v) = app.run("midi.new_clip", json!({"track": id.0, "start": sel.start, "end": sel.end})) {
            let _ = app.run("edit.select", json!({"clips": [v["clip"]]}));
        }
    }
}

fn grid_ticks_of(app: &SoundApp) -> i64 {
    match app.engine.session().edit.grid {
        soundcraft_time::GridValue::Note { value, dotted, triplet } => {
            let mut g = value.ticks();
            if dotted {
                g = g * 3 / 2;
            }
            if triplet {
                g = g * 2 / 3;
            }
            g.max(1)
        }
        _ => TICKS_PER_QUARTER / 4,
    }
}

fn midi_toolbar(app: &mut SoundApp, ui: &mut Ui, header: Rect, cid: ClipId, grid_ticks: i64) {
    let bar = Rect::from_min_max(pos2(header.min.x + 115.0, header.min.y + 1.0), pos2(header.max.x - 6.0, header.max.y - 1.0));
    let mut tb = ui.new_child(egui::UiBuilder::new().max_rect(bar).layout(egui::Layout::right_to_left(egui::Align::Center)));
    tb.spacing_mut().item_spacing.x = 5.0;

    let mut op: Option<(&str, serde_json::Value)> = None;
    if tb.small_button(crate::localization::text("Legato")).clicked() {
        op = Some(("event.change_duration", json!({"legato": 0})));
    }
    if tb.small_button(crate::localization::text("Vel −10")).clicked() {
        op = Some(("event.change_velocity", json!({"add": -10})));
    }
    if tb.small_button(crate::localization::text("Vel +10")).clicked() {
        op = Some(("event.change_velocity", json!({"add": 10})));
    }
    if tb.small_button(crate::localization::text("Quantize")).clicked() {
        op = Some(("event.quantize", json!({"grid": grid_ticks, "strength": 100})));
    }
    if let Some((id, mut p)) = op {
        p["clips"] = json!([cid.0]);
        let _ = app.run(id, p);
    }

    tb.separator();
    tb.checkbox(&mut app.midi.show_ghosts, "Ghosts");

    // Scale dropdown
    egui::ComboBox::from_id_salt("midi_scale_select")
        .selected_text(app.midi.scale.label())
        .width(135.0)
        .show_ui(&mut tb, |ui| {
            for sc in ScaleKind::ALL {
                ui.selectable_value(&mut app.midi.scale, sc, sc.label());
            }
        });

    // Root Key dropdown
    egui::ComboBox::from_id_salt("midi_root_key_select")
        .selected_text(ROOT_NAMES[usize::from(app.midi.root_key % 12)])
        .width(48.0)
        .show_ui(&mut tb, |ui| {
            for (idx, name) in ROOT_NAMES.iter().enumerate() {
                ui.selectable_value(&mut app.midi.root_key, idx as u8, *name);
            }
        });
    tb.label(egui::RichText::new("Scale:").font(regular(10.5)));
}

fn draw_roll_background(painter: &egui::Painter, g: &Roll<'_>, root_key: u8, scale: ScaleKind) {
    let Roll { roll, px_per_tick, len_ticks, grid_ticks, rows, row_h, .. } = *g;
    let top = g.pitch_at(roll.min.y);
    for r in 0..=rows + 1 {
        let pitch = top - r;
        let y = g.y_of(pitch);
        let row = Rect::from_min_size(pos2(roll.min.x, y), vec2(roll.width(), row_h));
        let base_col = if is_black(pitch) {
            Color32::from_rgb(28, 28, 31)
        } else {
            Color32::from_rgb(38, 38, 41)
        };
        painter.rect_filled(row, 0.0, base_col);

        // Faint scale highlighting when a non-chromatic scale is selected.
        if scale != ScaleKind::Chromatic && (0..=127).contains(&pitch) {
            let semi = ((pitch.rem_euclid(12) as u8) + 12 - (root_key % 12)) % 12;
            if scale.contains(semi) {
                let tint = if semi == 0 {
                    Color32::from_rgba_unmultiplied(110, 185, 255, 26)
                } else {
                    Color32::from_rgba_unmultiplied(110, 185, 255, 13)
                };
                painter.rect_filled(row, 0.0, tint);
            }
        }

        if pitch.rem_euclid(12) == 0 && (0..=127).contains(&pitch) {
            painter.line_segment(
                [pos2(roll.min.x, y + row_h), pos2(roll.max.x, y + row_h)],
                Stroke::new(1.0, Color32::from_rgb(64, 64, 70)),
            );
        }
    }

    let step = grid_stride(grid_ticks, px_per_tick);
    let mut tick = 0;
    while tick <= len_ticks {
        let bar = tick % (TICKS_PER_QUARTER * 4) == 0;
        let x = g.x_of(tick);
        painter.line_segment(
            [pos2(x, roll.min.y), pos2(x, roll.max.y)],
            Stroke::new(1.0, if bar { Color32::from_rgb(82, 82, 90) } else { Color32::from_rgb(50, 50, 55) }),
        );
        tick = tick.saturating_add(step);
    }
}

fn draw_and_interact_keys(app: &mut SoundApp, ui: &mut Ui, painter: &egui::Painter, g: &Roll<'_>) {
    let Roll { keys, rows, row_h, .. } = *g;
    let key_resp = ui.interact(keys, ui.scope_id().with("piano_keys"), Sense::click_and_drag());
    let hovered_pitch = key_resp
        .hover_pos()
        .or_else(|| key_resp.interact_pointer_pos())
        .map(|p| g.pitch_at(p.y).clamp(0, 127));

    if (key_resp.is_pointer_button_down_on() || key_resp.clicked())
        && let Some(pos) = key_resp.interact_pointer_pos()
    {
        let p = g.pitch_at(pos.y).clamp(0, 127) as u8;
        if app.midi.audition_pitch != Some(p) {
            trigger_audition(app, p, 18);
        }
    } else if key_resp.drag_stopped()
        && let Some(p) = app.midi.audition_pitch.take()
    {
        app.audition_midi_note(p, 0);
        app.midi.audition_frames = 0;
    }

    let top = g.pitch_at(keys.min.y);
    for r in 0..=rows + 1 {
        let pitch = top - r;
        if !(0..=127).contains(&pitch) {
            continue;
        }
        let y = g.y_of(pitch);
        let key = Rect::from_min_size(pos2(keys.min.x, y), vec2(keys.width() - 1.0, (row_h - 1.0).max(2.0)));
        let active = app.midi.audition_pitch == Some(pitch as u8) || hovered_pitch == Some(pitch);
        let col = if active {
            Color32::from_rgb(130, 195, 255)
        } else if is_black(pitch) {
            Color32::from_rgb(24, 24, 27)
        } else {
            Color32::from_rgb(228, 228, 232)
        };
        painter.rect_filled(key, 1.5, col);

        if pitch.rem_euclid(12) == 0 || row_h >= 13.0 {
            let text_col = if is_black(pitch) && !active {
                Color32::from_rgb(190, 190, 196)
            } else {
                Color32::from_rgb(35, 35, 40)
            };
            painter.text(
                pos2(key.max.x - 4.0, key.center().y),
                Align2::RIGHT_CENTER,
                soundcraft_midi::note_name(pitch as u8),
                regular(8.5),
                text_col,
            );
        }
    }
}

/// Draw ghost notes from other MIDI clips on the playlist aligned to the active clip's timeline.
fn draw_ghost_notes(
    painter: &egui::Painter,
    g: &Roll<'_>,
    session: &soundcraft_model::Session,
    active_cid: ClipId,
    base_tick: i64,
    sr: soundcraft_time::SampleRate,
) {
    let Roll { row_h, .. } = *g;
    for tr in &session.tracks {
        if !tr.kind.is_midi() {
            continue;
        }
        let ghost_col = Color32::from_rgba_unmultiplied(tr.color[0], tr.color[1], tr.color[2], 52);
        let ghost_stroke = Stroke::new(1.0, Color32::from_rgba_unmultiplied(tr.color[0], tr.color[1], tr.color[2], 95));
        for c in tr.clips() {
            if c.id == active_cid {
                continue;
            }
            let ClipContent::Midi { sequence } = &c.content else {
                continue;
            };
            let other_base = session.tempo.samples_to_ticks(c.start, sr);
            let offset = other_base - base_tick;
            for n in &sequence.notes {
                let st = n.start + offset;
                let en = st + n.length;
                if en < 0 || st > g.len_ticks {
                    continue;
                }
                let p = i32::from(n.pitch);
                let r = Rect::from_min_max(
                    pos2(g.x_of(st), g.y_of(p) + 1.5),
                    pos2(g.x_of(en).max(g.x_of(st) + 3.0), g.y_of(p) + row_h - 1.5),
                );
                painter.rect(r, 2.0, ghost_col, ghost_stroke, StrokeKind::Inside);
            }
        }
    }
}

const MIN_GRID_PX: f32 = 4.0;

fn grid_stride(grid_ticks: i64, px_per_tick: f32) -> i64 {
    let bar_ticks = TICKS_PER_QUARTER * 4;
    if grid_ticks as f32 * px_per_tick > MIN_GRID_PX {
        return grid_ticks.max(1);
    }
    let grid = grid_ticks.max(1);
    let (mut a, mut b) = (grid, bar_ticks);
    while b != 0 {
        (a, b) = (b, a % b);
    }
    let common = (grid / a).saturating_mul(bar_ticks);
    let n = (MIN_GRID_PX / (common as f32 * px_per_tick)).ceil().max(1.0) as i64;
    common.saturating_mul(n)
}

fn draw_notes(app: &SoundApp, painter: &egui::Painter, g: &Roll<'_>, base: Color32) {
    let Roll { sequence, grid_ticks, row_h, .. } = *g;
    let drag = app.midi.drag.clone();
    for (i, n) in sequence.notes.iter().enumerate() {
        let (mut st, mut ln, mut p) = (n.start, n.length, i32::from(n.pitch));
        if let Some(d) = &drag
            && (d.index == i || (!d.resize && app.midi.selected.contains(&i) && app.midi.selected.contains(&d.index)))
        {
            if d.resize {
                if d.index == i {
                    ln = (ln + d.dx_ticks).max(grid_ticks.min(ln).max(1));
                }
            } else {
                st = (st + d.dx_ticks).max(0);
                p = (p + d.dy_semi as i32).clamp(0, 127);
            }
        }
        let r = Rect::from_min_max(
            pos2(g.x_of(st), g.y_of(p) + 1.0),
            pos2(g.x_of(st + ln).max(g.x_of(st) + 3.0), g.y_of(p) + row_h - 1.0),
        );
        let sel = app.midi.selected.contains(&i);
        let k = 0.45 + 0.55 * f32::from(n.velocity) / 127.0;
        let fill = if sel {
            Color32::WHITE
        } else {
            Color32::from_rgb(
                (f32::from(base.r()) * k) as u8,
                (f32::from(base.g()) * k) as u8,
                (f32::from(base.b()) * k) as u8,
            )
        };
        painter.rect(r, 2.0, fill, Stroke::new(1.0, Color32::BLACK), StrokeKind::Inside);
    }
}

fn note_pointer(app: &mut SoundApp, ui: &mut Ui, g: &Roll<'_>, cid: ClipId, pencil: bool) {
    let Roll { sequence, roll, px_per_tick, grid_ticks, row_h, .. } = *g;
    let resp = ui.interact(roll, ui.scope_id().with(("roll", cid.0)), Sense::click_and_drag());
    if resp.drag_started()
        && let Some(p) = resp.interact_pointer_pos()
    {
        if let Some((i, edge)) = g.hit(p) {
            if !app.midi.selected.contains(&i) {
                app.midi.selected = vec![i];
            }
            if let Some(n) = sequence.notes.get(i) {
                trigger_audition(app, n.pitch, 14);
            }
            app.midi.drag = Some(NoteDrag { index: i, resize: edge, start: p, dx_ticks: 0, dy_semi: 0 });
        } else {
            app.midi.band = Some(p);
        }
    }
    if let (Some(a), Some(b)) = (app.midi.band, ui.ctx().pointer_latest_pos()) {
        let band = Rect::from_two_pos(a, b).intersect(roll);
        ui.painter().rect(
            band,
            0.0,
            Color32::from_rgba_unmultiplied(120, 170, 255, 40),
            Stroke::new(1.0, Color32::from_rgb(120, 170, 255)),
            StrokeKind::Inside,
        );
        if resp.drag_stopped() {
            app.midi.selected = sequence
                .notes
                .iter()
                .enumerate()
                .filter(|(_, n)| {
                    let r = Rect::from_min_max(
                        pos2(g.x_of(n.start), g.y_of(i32::from(n.pitch))),
                        pos2(g.x_of(n.start + n.length), g.y_of(i32::from(n.pitch)) + row_h),
                    );
                    r.intersects(band)
                })
                .map(|(i, _)| i)
                .collect();
            app.midi.band = None;
        }
    }
    if resp.dragged()
        && let (Some(d), Some(p)) = (&mut app.midi.drag, resp.interact_pointer_pos())
    {
        let prev_dy = d.dy_semi;
        d.dx_ticks = g.snap((p.x - d.start.x) / px_per_tick);
        d.dy_semi = -((p.y - d.start.y) / row_h).round() as i64;
        if !d.resize
            && d.dy_semi != prev_dy
            && let Some(n) = sequence.notes.get(d.index)
        {
            let new_pitch = (i32::from(n.pitch) + d.dy_semi as i32).clamp(0, 127) as u8;
            trigger_audition(app, new_pitch, 12);
        }
    }
    if resp.drag_stopped()
        && let Some(d) = app.midi.drag.take()
    {
        if d.resize {
            if let Some(n) = sequence.notes.get(d.index) {
                let _ = app.run(
                    "midi.note_edit",
                    json!({"clip": cid.0, "index": d.index, "length_ticks": (n.length + d.dx_ticks).max(1)}),
                );
            }
        } else if d.dx_ticks != 0 || d.dy_semi != 0 {
            let _ = app.run(
                "midi.notes_move",
                json!({"clip": cid.0, "indices": app.midi.selected, "ticks": d.dx_ticks, "semitones": d.dy_semi}),
            );
            app.midi.selected.clear();
        }
    }
    if resp.double_clicked()
        && let Some(p) = resp.interact_pointer_pos()
    {
        if let Some((i, _)) = g.hit(p) {
            let _ = app.run("midi.note_delete", json!({"clip": cid.0, "indices": [i]}));
            app.midi.selected.retain(|selected| *selected != i);
        } else {
            let pitch = g.pitch_at(p.y).clamp(0, 127);
            let start = g.snap(((p.x - roll.min.x) / px_per_tick + g.scroll_x_ticks).max(0.0));
            let _ = app.run(
                "midi.note_add",
                json!({"clip": cid.0, "pitch": pitch, "start_ticks": start.max(0), "length_ticks": grid_ticks, "velocity": 100}),
            );
            trigger_audition(app, pitch as u8, 16);
            app.midi.selected.clear();
        }
    } else if resp.clicked()
        && let Some(p) = resp.interact_pointer_pos()
    {
        match g.hit(p) {
            Some((i, _)) => {
                if ui.input(|x| x.modifiers.shift) {
                    if !app.midi.selected.contains(&i) {
                        app.midi.selected.push(i);
                    }
                } else {
                    app.midi.selected = vec![i];
                }
                if let Some(n) = sequence.notes.get(i) {
                    trigger_audition(app, n.pitch, 14);
                }
            }
            None if pencil => {
                let pitch = g.pitch_at(p.y).clamp(0, 127);
                let start = g.snap(((p.x - roll.min.x) / px_per_tick + g.scroll_x_ticks).max(0.0));
                let _ = app.run(
                    "midi.note_add",
                    json!({"clip": cid.0, "pitch": pitch, "start_ticks": start.max(0), "length_ticks": grid_ticks, "velocity": 100}),
                );
                trigger_audition(app, pitch as u8, 16);
                app.midi.selected.clear();
            }
            None => app.midi.selected.clear(),
        }
    }
}

fn note_keys(app: &mut SoundApp, ui: &mut Ui, g: &Roll<'_>, cid: ClipId) {
    let Roll { sequence, roll, grid_ticks, .. } = *g;
    if ui.rect_contains_pointer(roll) && !ui.ctx().egui_wants_keyboard_input() {
        let (all, up, down, left, right, shift) = ui.input(|i| {
            let arrows = !i.modifiers.alt && !i.modifiers.command && !i.modifiers.ctrl;
            (
                i.modifiers.command && i.key_pressed(egui::Key::A),
                arrows && i.key_pressed(egui::Key::ArrowUp),
                arrows && i.key_pressed(egui::Key::ArrowDown),
                arrows && !i.modifiers.shift && i.key_pressed(egui::Key::ArrowLeft),
                arrows && !i.modifiers.shift && i.key_pressed(egui::Key::ArrowRight),
                i.modifiers.shift,
            )
        });
        if all {
            app.midi.selected = (0..sequence.notes.len()).collect();
        }
        let semi = if up {
            1
        } else if down {
            -1
        } else {
            0
        } * if shift { 12 } else { 1 };
        let ticks = if right {
            grid_ticks
        } else if left {
            -grid_ticks
        } else {
            0
        };
        if (semi != 0 || ticks != 0) && !app.midi.selected.is_empty() {
            let moved = app.run(
                "midi.notes_move",
                json!({"clip": cid.0, "indices": app.midi.selected, "ticks": ticks, "semitones": semi}),
            );
            app.midi.selected = moved.ok().and_then(|v| serde_json::from_value(v["indices"].clone()).ok()).unwrap_or_default();
        }
    }
    if !app.midi.selected.is_empty()
        && !ui.ctx().egui_wants_keyboard_input()
        && ui.input(|i| i.key_pressed(egui::Key::Delete) || i.key_pressed(egui::Key::Backspace))
    {
        let _ = app.run("midi.note_delete", json!({"clip": cid.0, "indices": app.midi.selected}));
        app.midi.selected.clear();
    }
}

fn velocity_lane(app: &mut SoundApp, ui: &mut Ui, g: &Roll<'_>, cid: ClipId, base: Color32, label_x: f32) {
    let Roll { sequence, vel, .. } = *g;
    let t = Tokens::current();
    ui.painter().rect_filled(vel, 0.0, Color32::from_rgb(28, 28, 30));
    ui.painter().text(
        pos2(label_x, vel.center().y),
        Align2::LEFT_CENTER,
        crate::localization::text("Velocity"),
        regular(10.0),
        t.text_dim,
    );
    let vel_painter = ui.painter().with_clip_rect(vel);
    let vresp = ui.interact(vel, ui.scope_id().with(("vel", cid.0)), Sense::click_and_drag());
    for (i, n) in sequence.notes.iter().enumerate() {
        let x = g.x_of(n.start);
        let h = (vel.height() - 4.0) * f32::from(n.velocity) / 127.0;
        let col = if app.midi.selected.contains(&i) { Color32::WHITE } else { base };
        vel_painter.line_segment([pos2(x + 1.0, vel.max.y - 2.0), pos2(x + 1.0, vel.max.y - 2.0 - h)], Stroke::new(3.0, col));
        vel_painter.circle_filled(pos2(x + 1.0, vel.max.y - 2.0 - h), 2.5, col);
    }
    if (vresp.clicked() || vresp.dragged())
        && let Some(p) = vresp.interact_pointer_pos()
        && let Some((i, n)) = sequence
            .notes
            .iter()
            .enumerate()
            .min_by_key(|(_, n)| ((g.x_of(n.start) - p.x).abs() * 10.0) as i64)
        && (g.x_of(n.start) - p.x).abs() < 8.0
    {
        let v = (((vel.max.y - 2.0 - p.y) / (vel.height() - 4.0)) * 127.0).round().clamp(1.0, 127.0) as i64;
        let _ = app
            .engine
            .execute_merged("midi.note_edit", &json!({"clip": cid.0, "index": i, "velocity": v}), &format!("vel:{}", cid.0));
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn grid_lines_are_bounded_by_the_roll_width_not_the_clip_length() {
        let sixteenth = TICKS_PER_QUARTER / 4;
        assert_eq!(grid_stride(sixteenth, 1000.0 / (16.0 * TICKS_PER_QUARTER as f32)), sixteenth);
        let (len, px_per_tick) = (1_000_000_000i64, 1000.0 / 1_000_000_000.0f32);
        let step = grid_stride(sixteenth, px_per_tick);
        assert_eq!(step % (TICKS_PER_QUARTER * 4), 0, "lines fall on bars");
        assert!((len / step) <= 251, "{} lines", len / step);
        let dotted = TICKS_PER_QUARTER * 3 / 2;
        let step = grid_stride(dotted, px_per_tick);
        assert_eq!((step % dotted, step % (TICKS_PER_QUARTER * 4)), (0, 0), "lines are snap positions on bars: {step}");
        assert!((len / step) <= 251, "{} lines", len / step);
        assert!(grid_stride(0, 0.0) >= TICKS_PER_QUARTER * 4, "a zero grid or width still advances");
    }

    #[test]
    fn switching_clip_drops_selection_and_gestures() {
        let mut st = MidiEditorState { selected: vec![0, 2], clip: Some(ClipId(1)), band: Some(pos2(1.0, 2.0)), ..Default::default() };
        st.switch_clip(ClipId(1));
        assert_eq!(st.selected, vec![0, 2]);
        st.switch_clip(ClipId(2));
        assert!(st.selected.is_empty());
        assert!(st.drag.is_none() && st.band.is_none());
        assert_eq!(st.clip, Some(ClipId(2)));
    }

    #[test]
    fn scale_contains_expected_intervals() {
        assert!(ScaleKind::Major.contains(0));
        assert!(ScaleKind::Major.contains(4));
        assert!(ScaleKind::Major.contains(7));
        assert!(!ScaleKind::Major.contains(3));
        assert!(ScaleKind::NaturalMinor.contains(3));
        assert!(ScaleKind::Blues.contains(6));
    }
}
